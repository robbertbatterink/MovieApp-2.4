import React from 'react';
import './WelcomeImage.css';

const WelcomeImage = (props) => {
	//const imgUrl = 'http://localhost:3000/static/media/BohemianRapsody_full.f80decef.jpg'
	//const divStyle = {
	//	backgroudColor: '#000 !important',
	//	backgroundImage: 'url(' + imgUrl + ')',
 //};
	return (
		<div className="WelcomeImage"></div>
	)
};

export default WelcomeImage;
  // background: url("img/bg2.jpg") center center no-repeat;
