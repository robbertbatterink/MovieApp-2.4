import React from 'react';
import "./MovieDetailImage.css";

const MovieDetailImage = () => {
  return (
    <div className="MovieDetailImage">MovieDetailImage</div>
  )
}

export default MovieDetailImage
