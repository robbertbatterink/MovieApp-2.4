import React from 'react';

const MovieDetail = () => {
  <div>Movie Detail...</div>
}

export default MovieDetail;
